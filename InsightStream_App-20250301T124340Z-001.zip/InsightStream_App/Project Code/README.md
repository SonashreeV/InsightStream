# InsightStream - News Web Application

## Project Overview
InsightStream is a simple news web application developed using React.js. It allows users to browse news articles by category, view trending news, and subscribe to the newsletter.

## Features
- Display Trending News
- Browse News by Categories
- Newsletter Subscription
- Responsive Design

## Technologies Used
- React.js
- Axios (API Integration)
- React Router DOM
- CSS for styling

## How to Run the Project
### Prerequisites
- Node.js installed
- VS Code or any code editor

### Steps to Run the Project
1. Download the project folder.
2. Open the folder in **VS Code**.
3. Install dependencies:
   ```bash
   npm install
   ```
4. Start the development server:
   ```bash
   npm start
   ```
5. Open **http://localhost:3000** in your browser.

## Folder Structure
```
InsightStream/
├─ src/
│  ├─ Components/
│  │   ├─ Navbar.jsx
│  │   ├─ HeroSection.jsx
│  │   └─ Newsletter.jsx
│  ├─ Pages/
│  ├─ App.jsx
│  ├─ index.js
│  └─ Styles/
└─ package.json
```

## API Used
News data is fetched using custom API.

## Screenshots
- Home Page
- Category Page
- Newsletter Page

## Developed By
- Sonashree V
- Dheekshitha K
- Lakshitha B
- Sweatha K M
- Jennifer A L


